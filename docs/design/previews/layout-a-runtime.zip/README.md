# Kho mẫu — phương án A

Bản vá mã chạy và kiểm tra trên nền commit 66be614efc8eb2c2b6c9c320014cb0d15db0acc4 của Lo75d1/dinhduong-web. Đã kiểm git apply --check trên nền này. Chứa 10 file runtime/test, không chứa prototype A/B hoặc PRODUCT/DESIGN.

Từ checkout đúng phiên bản nền:

```sh
git apply --check /duong-dan/layout-a-runtime.patch
git apply /duong-dan/layout-a-runtime.patch
```

Không có migration mới. Gói này để chủ dự án xem và chuyển giao; chưa cập nhật GitHub/VPS.
